<div>
    <a href="?pays=en"><img src="img/england.png" alt="drapeau de l'Angleterre"></a>
    <a href="?pays=es"><img src="img/spain.png" alt="drapeau de l'Espagne"></a>
    <a href="?pays=dz"><img src="img/algeria.png" alt="drapeau de l'Algérie"></a>
</div>
<?php require_once('inc/header.inc.php') ?>

        <h1>Accueil</h1>

        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Praesentium, sunt nobis sequi error repellendus iure sint tenetur. Sunt veniam, tenetur ratione dolorum nesciunt aperiam dolores delectus nostrum. Aspernatur, dicta vitae.</p>

<?php require_once('inc/footer.inc.php');
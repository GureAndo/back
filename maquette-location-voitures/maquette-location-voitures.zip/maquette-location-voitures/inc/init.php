<?php

// PDO est une surcouche de PHP, surcouche d'abstraction, qui permet d'interagir avec la base de données.
// Nous disposerons ainsi de plusieurs fonctions prédéfines propres a la classe PDO
// pour pouvoir les exploiter, je dois créer un objet $pdo de ma classe PDO
// je ne suis pas obligé de l'appeler ainsi. Vouc trouverez parfois le nom de $bdd.Le plus important est qu'elle ait un nom cohérent.
// pour me connecter à la base de données je dois renseigner le host. Comme nous sommes en local, àça sera localhost
// le dbname, c'est le nom de ma base de données (nous avons choisi voiture)
// root est le nom du dbuser (identifiant de l'utilisateur) en localhost
// les quotes vides '' sont pour le dbpassword (mot de passe pour la base de données).En local il doit rester vide. Pas de mot de passe
$pdo = new PDO('mysql:host=localhost;dbname=voiture', 'root', '', array(
    // dans ce array/tableau, je vais définir deux parametres
    // le premier concerne le mode d'erreur que je veux recevoir en affichage lorsqu'il y en a. Je choisi le mode warning
    PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING,
    // ci-dessous, je décide du type d'encodage que je veux vers la base de données (utf8, comme dans le doctype)
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
));
// j'initialise ici aussi ces deux variables, a vide (ne rien ecrire entre les quetos, même pas un espace). Car je vais en avoir besoin dans toutes mes pages du site
$erreur = '';
$content = '';